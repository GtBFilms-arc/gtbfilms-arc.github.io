GonadoVision Unreal Tournament Skins Set Version 2.0
====================================================


Installing the GonadoVision Unreal Tournament Skins
===================================================

Unzip this archive, and place the 'SoldierSkins_gonads.int' file in your Unreal Tournament/System directory.

Place the 'SoldierSkins_gonads.utx' file in the Unreal Tournament/Textures directory.

That's it - the new skins (6 of them) are now available in the game from Player Setup - you can also set  up the bots to use the skins!

To select them, select model type 'Male Soldier' and the subtype 'GonadoVision' will appear, then select the charactername to set the face.

I found this works fine on a single machine, but if yours is ever going to be the server on a multiplayer LAN or internet game, you also need to do the following (otherwise everyone else just sees a skinless (green fluorescent) model:

Edit the file UnrealTournament.ini in the system directory, and scroll down until you find the bit like this:

ServerPackages=SoldierSkins
ServerPackages=CommandoSkins
ServerPackages=FCommandoSkins
ServerPackages=SGirlSkins
ServerPackages=BossSkins
ServerPackages=Botpack

On the next line, add the following:

Serverpackages=Soldierskins_gonads

This means that if your machine is the server, it will know to check all the other people playing have the required skins, if they do not, then they can download them from your server. Thus it is NOT a good idea to use these skins if you are thinking of going online and being a server machine (i.e.  creating an internet game of your own, rather than joining someone elses), as peopel might get a bit fed up by the fact that they have to download 1.5Mb of GonadoVision skins before the ganme starts.

History
=======
V.2.0 - 5th April 2000
Baldas skin and Bruiser skin redesigned to make them more accurate.

V.1.2 - 1st Feb 2000
Added the Bruiser skin, altered costume (for all colours and standard) to include the GonadoVision logo.
Removed last of the original Overkill skins from the pack.


V.1.1 - 9th Jan 2000
Added higher quality Gonad skin, using image captured especially for creating the skin.

V.1.0 - 9th Jan 2000
First version completed, these skins are just the Overkill skins set with the faces changed - at present  there are only: Internet Jim, Baldas and Magnox. There is also two original robot faces from the Overkill set, which will be replaced with a Brucey face and a Gonad face when I get a good picture.

