
Resize.


Thumbnailing software


Created by Peter Bone

email : peterbone@hotmail.com
URL   : http://www.geocities.com/peter_bone_uk

5 / 2 / 2005


Resize allows you to resize a batch of bitmaps/jpegs or convert them to 
jpeg/bitmap or both. This is useful for creating many thumbnails for a 
website simultaneously. It is also useful for resizing frames before
creating animated gifs.

There are 4 ways to resize images. Firstly, you can resize by percentage, 
which will resize all images by the same ratio. You can also resize by 
height or width to make all the images the same height or width. The last 
option is to resize the maximum dimension of the image to a given size 
- i.e. if the image is portrait then the height will be resized to the 
given size and if the image is landscape then the width will be resized 
to the given size. Aspect ratio is always maintained.

Image shrinking is done using pixel-averaging, which gives much higher
quality than sub-sampling. Image enlargment is also done using pixel-
averaging, unlike most other image editing software.

Each resized/converted image will be automatically saved to the same 
location that it's original came from and given a prefix so that it 
doesn't overwrite the original. You can also choose to save the new
files to a specified location by changing the destination settings from
the options menu. The prefix can also be changed.

By right clicking in the image file list, you can view that image or 
delete all selected images. Select multiple images by using the shift or 
control keys.

You can open the program with files already listed by selecting the files 
in a folder and dragging them onto the Resize icon or associating certain
file types with Resize.

Resize now supports drag and drop from windows explorer. This means you 
can drag files directly into resize from a windows folder.

Now has an option to maintain EXIF data. EXIF data is information
stored in the jpeg by digital cameras. If you maintain the EXIF data
the resized file may be larger than expected since it may contain an
EXIF thumbnail image.
